# Arduino Redis Library

An Arduino library for Redis that works on ESP8266.
It supports get, set, publish, subscribe.

### Examples

- Pub_Sub: An example of pub/sub application with the Redis library.
- Simple: Open the connection, set and get a key then close the connection.

### Question

If you have any question please open an issue.

### Work in progress

- Subscribe function.
